﻿
namespace TestMatchProfile.WebApi.Extensions
{
    public class AuthorizationConsts
    {
        public const string AdminPolicy = "AdminPolicy";
        public const string ManagerPolicy = "ManagerPolicy";
        public const string EmployeePolicy = "EmployeePolicy";
    }
}
