﻿namespace TestMatchProfile.WebApi.Models
{
    public class Metadata
    {
    }
}