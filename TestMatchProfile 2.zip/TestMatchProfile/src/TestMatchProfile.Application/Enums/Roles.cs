﻿namespace TestMatchProfile.Application.Enums
{
    public enum Roles
    {
        SuperAdmin,
        Admin,
        Manager,
        Employee
    }
}