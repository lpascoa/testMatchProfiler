﻿//using System.Collections.Generic;
//using TestMatchProfile.Domain.Entities;

//namespace TestMatchProfile.Application.Interfaces
//{
//    public interface IMockService
//    {
//        List<LegalContract> GetLegalContracts(int rowCount);

//        List<Position> GetPositions(int rowCount);

//        List<Employee> GetEmployees(int rowCount);

//        List<Position> SeedPositions(int rowCount);
//    }
//}