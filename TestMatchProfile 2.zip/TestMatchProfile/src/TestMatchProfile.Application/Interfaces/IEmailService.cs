﻿//using System.Threading.Tasks;
//using TestMatchProfile.Application.DTOs.Email;

//namespace TestMatchProfile.Application.Interfaces
//{
//    public interface IEmailService
//    {
//        Task SendAsync(EmailRequest request);
//    }
//}