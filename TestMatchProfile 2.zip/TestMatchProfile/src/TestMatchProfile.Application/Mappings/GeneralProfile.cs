﻿using AutoMapper;
using TestMatchProfile.Application.Features.Employees.Queries.GetEmployees;
using TestMatchProfile.Application.Features.Positions.Commands.CreatePosition;
using TestMatchProfile.Application.Features.Positions.Queries.GetPositions;
using TestMatchProfile.Domain.Entities;

namespace TestMatchProfile.Application.Mappings
{
    public class GeneralProfile : Profile
    {
        public GeneralProfile()
        {
            CreateMap<Position, GetPositionsViewModel>().ReverseMap();
            CreateMap<Employee, GetEmployeesViewModel>().ReverseMap();
            CreateMap<CreatePositionCommand, Position>();
        }
    }
}