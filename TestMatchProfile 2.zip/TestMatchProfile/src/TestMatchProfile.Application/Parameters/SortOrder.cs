﻿namespace TestMatchProfile.Application.Parameters
{
    public class SortOrder
    {
        public int Column { get; set; }
        public string Dir { get; set; }
    }
}