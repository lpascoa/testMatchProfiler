﻿namespace TestMatchProfile.Application.Parameters
{
    public class Search
    {
        public string Value { get; set; }
        public bool Regex { get; set; }
    }
}