﻿namespace TestMatchProfile.Domain.Enums
{
    public enum Gender
    {
        Male,
        Female
    }
}